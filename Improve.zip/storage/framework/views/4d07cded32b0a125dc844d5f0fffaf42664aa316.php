<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        

            <h4 align=center> Historias en papelera  <?php echo e($num_eliminados); ?> </h4>
            <?php if( $num_eliminados > 0 ): ?> 

    <table width="100" class="table table-striped table-hover table-reflow">
        <thead>
            <tr>
                <th ><strong> Título </strong></th>
                <th ><strong> Sprint </strong></th>
                <th ><strong> Creado por </strong></th>
                <th ><strong> Estimación </strong></th>
                <th ><strong> Prioridad </strong></th>
                <th ><strong> Historial </strong></th>
                <th ><strong> Eliminar definitivamente </strong></th>
                <th ><strong> Recuperar historia </strong></th>
            </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <a href="/pbis/edit/<?php echo e($pbi->id); ?>" > <?php echo e($pbi->titulo); ?></a> </td>
                <td> <a href="/sprints/<?php echo e($pbi->sprint_id); ?>" > <?php echo e($pbi->nombre); ?></a></td>
                <td>  <?php echo e($pbi->creado_por); ?> </td>
                <td>  <?php echo e($pbi->estimacion); ?> </td>
                <td>  
                    <?php if($pbi->prioridad_id == 3): ?>
                        Baja
                          <?php elseif($pbi->prioridad_id == 2): ?>
                            Media
                              <?php else: ?>
                                  Alta
                    <?php endif; ?>  
                </td>
                <td>  
                    <a href="/pbis/<?php echo e($pbi->id); ?>/historial" class="btn btn-primary btn-sm">
                        <i class="fa fa-book" aria-hidden="true"></i> 
                        Historial</a>
                </td>
                <td> 
                    <a 
                        onclick="return confirm('¿Quiere eliminar la historia y todos sus registros?')"
                        href="/pbis/delete/<?php echo e($pbi->id); ?>"   
                        class="btn btn-danger btn-sm"> 
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </a>
                </td>
                <td> 
                    <a 
                        href="/pbis/recuperar/<?php echo e($pbi->id); ?>"   
                        class="btn btn-primary btn-sm"> 
                        <i class="fa fa-check" aria-hidden="true"></i>
                    </a>
                </td>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
    </table>
 <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>