<?php $__env->startSection('content'); ?>


<div class="row tm-content-row">
    <div class="col-md-6">
        <div class="panel panel-default ">
            <div class="panel-heading" > <p class="text-white"> Proyectos </p>
        
            </div>
            <div class="panel-body" >
                <ul class="list-group">
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"> 
                        <i class="fa fa-play" aria-hidden="true"></i>
                        <a href="/projects/<?php echo e($proyecto->id); ?>" > <?php echo e($proyecto->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>