<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">
        <form method="post" action="<?php echo e(route('usuarios.update')); ?>">
                <?php echo e(csrf_field()); ?>


	    <input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">

    	<div class="form-group<?php echo e($errors->has('usuario') ? ' has-error' : ''); ?>">
    		<label>Usuario</label>
            <input type="text" class="form-control"  
            name="usuario" value="<?php echo e($user->usuario); ?>">
            <?php if($errors->has('usuario')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('usuario')); ?></strong>
                  </span>
                <?php endif; ?> 
        </div>
        
        <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                <label>Nombres</label>
                <input type="text" class="form-control" placeholder="Nombres"
                name="nombre" value="<?php echo e($user->nombres); ?>">
                <?php if($errors->has('nombre')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('nombre')); ?></strong>
                  </span>
                <?php endif; ?> 
        </div>

        <div class="form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
                <label>Apellidos</label>
                <input type="text" class="form-control" placeholder="Apellidos"
                name="apellido" value="<?php echo e($user->apellidos); ?>">
                <?php if($errors->has('apellido')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('apellido')); ?></strong>
                  </span>
                <?php endif; ?> 
        </div>
        
    	<div class="form-group">
    		<label>Descripción</label>
            <textarea class="form-control my-editor" placeholder="Información acerca de ti"
            rows="4" id="task" name="descripcion"><?php echo e($user->descripcion_user); ?></textarea>
		</div>
    
	

        <div class="btn-group">
            <input class="btn btn-primary" type="submit" value="Guardar">

            <a class="btn btn-danger" 
            href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>">Retroceder</a>

        </form>
    </div>
</div>  

    <div class="col-md-4">
        <div class="tm-bg-primary-dark tm-block">
            <h5>Opcion <h5>
       
                <a  onclick="return confirm
                ('¿Desea eliminar su cuenta? Se eliminara toda la inforacion relacionada')"
                    href="/usuarios/<?php echo e($user->id); ?>/eliminar">  
                    <i class="fa fa-power-off" aria-hidden="true"></i> Eliminar cuenta</a>
                </a> 
      
        </div>
    </div>  


       
   


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>