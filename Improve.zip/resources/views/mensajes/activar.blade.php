Welcome {{ $usuario }},
VIsit the next link to activate your account: {{ url('usuarios/activacion', $link)}}
{{-- En el siguiente enlace podra activar su cuenta: {{ url('usuarios/activacion', $link)}} --}}
