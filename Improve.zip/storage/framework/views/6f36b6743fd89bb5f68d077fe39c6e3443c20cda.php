<?php $__env->startSection('content'); ?>


<h1 align=center>
    <?php echo e(count($usuarios)); ?> Usuarios registrados en el sistema
</h1>
<table width="70"  class="table table-striped table-hover table-reflow">
    <thead>
        <tr>
            <th><strong> Usuario </strong></th>
            <th><strong> Email </strong></th>
            <th><strong> Apellidos </strong></th>
            <th><strong> Nombres </strong></th>
            <th><strong> Opciones </strong></th>
            <th><strong> Estado cuenta </strong></th>
        </tr>
    </thead>

    <tbody>
        
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($usuario->usuario); ?></a> </td>    
                    
                <td> <?php echo e($usuario->email); ?> </td>
                <td> <?php echo e($usuario->apellidos); ?> </td>
                <td> <?php echo e($usuario->nombres); ?> </td>
                <td> 
                    <a 
                        href="/usuarios/<?php echo e($usuario->id); ?>/eliminar"   
                        class="btn btn-danger btn-sm"> 
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </a>
                </td>
                <td>
                    <?php if($usuario->activado==1): ?>    
                        <a 
                            href="/usuarios/<?php echo e($usuario->id); ?>/activacion"   
                            class="btn btn-primary btn-sm"> 
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </a>
                    <?php else: ?>
                        <a href="/usuarios/<?php echo e($usuario->id); ?>/activacion"   
                            class="btn btn-danger btn-sm"> 
                            <i class="fa fa-ban" 
                                    aria-hidden="true"></i>
                            
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

    </tbody>
</table>


  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>