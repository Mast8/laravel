Estimado {{ $usuario }},
se le comunica que se le asigno la tarea: {{ $tarea }}
