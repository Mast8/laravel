<html>
    
    <title> Reporte de Sprints </title>
<head>

    <style>
        h1 { color: #8f9595; }
        h2 { color: #667373; }
        h3 { color: #567086; }
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
            font-size:	10px;

        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
    tr:nth-child(even) {
        background-color: #dddddd;
    }
    </style>
</head>

<head>
<body>

    PROYECTO: <h1 >  <?php echo e($proyecto->name); ?> </h1>

        
    <h2 align="center">
        Sprints
    </h2>
    <?php if(count($sprints)>0): ?>
    <h3 align="center">
        Se registraron <b> <?php echo e(count($sprints)); ?> </b> Sprints.
    </h3>
        <table>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
            </tr>

            <?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sprint->nombre); ?></td>
                    
                    <td><?php echo e($sprint->descripcion); ?></td> 
                    
                    
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </table>
    <?php else: ?>
        <h2 align="center">
            NO SE TIENEN DATOS REGISTRADOS.
        </h2>
    <?php endif; ?>
</head>