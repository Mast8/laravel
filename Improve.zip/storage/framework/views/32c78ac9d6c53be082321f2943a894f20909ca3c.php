<html>
    
    <title> Reporte Product Backlog </title>
<head>

    <style>
        h1 { color: #8f9595; }
        h2 { color: #667373; }
        h3 { color: #567086; }
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
            font-size:	10px;
        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
    
    </style>
</head>

<head>
<body>

    PROYECTO: <h1 >  <?php echo e($proyecto->name); ?> </h1>

        
    <h2 align="center">
        PRODUCT BACKLOG
    </h2>
    <?php if(count($pbis)>0): ?>
    <h3 align="center">
        Se registraron <b> <?php echo e(count($pbis)); ?> </b> historias de usuario.
    </h3>
        <table>
            <tr>
                <th>PBI</th>
                <th>SPRINT</th>
                <th>CREADO POR</th>
                
                <th>ESTIMACIÓN</th>
                <th>PRIORIDAD</th>
                
            </tr>
            <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pbi->titulo); ?></td>
                    <td><?php echo e($pbi->nombre); ?></td>
                    <td><?php echo e($pbi->creado_por); ?></td> 
                    <td><?php echo e($pbi->estimacion); ?></td>
                    <td><?php echo e($pbi->nombrePrio); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
    <?php else: ?>
        <h2 align="center">
            NO SE TIENEN DATOS REGISTRADOS.
        </h2>
    <?php endif; ?>
</head>