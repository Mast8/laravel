Bienvenido <?php echo e($usuario); ?>,
En el siguiente enlace podra activar su cuenta: <?php echo e(url('usuarios/activacion', $link)); ?>

