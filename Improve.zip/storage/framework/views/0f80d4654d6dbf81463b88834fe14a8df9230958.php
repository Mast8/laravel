Estimado <?php echo e($usuario); ?>,
se le informa que se modifico la siguiente tarea: <?php echo e($tarea); ?>

