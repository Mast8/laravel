<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('tareas.create', ['idpbi' => $idpbi])); ?>" 
        class="pull-right btn btn-primary btn-sm">
        <span 
        class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
    </a> 

    <div class="row task-list-row">
        <div class="col-xs-12 col-md-4">
            <ul class="list-group">
                    <h5 class="title">In Progress </h5>
                <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="/historias/<?php echo e($pbi->id); ?>" > <?php echo e($pbi->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        </div>
    
        <div class="col-xs-12 col-md-4">
            <ul class="task-list">
                <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pbi->days === 2): ?>
                        <a href="/historias/<?php echo e($pbi->id); ?>" > <?php echo e($pbi->name); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        </div>
        
        <div class="col-xs-12 col-md-4">
            <ul class="task-list">
                    <div>
                        <div class="show-on-hover pull-right">
                        </div>
                    </div>
                    <div>

                    </div>
                </li>
            </ul>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>