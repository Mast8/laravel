<?php $__env->startSection('content'); ?>



    
            <a class="btn btn-primary" 
              href="<?php echo e(route('pbis.edit', ['id' => $pbi->id] )); ?>">
              Volver a la historia</a>
      
            <a  
              href="<?php echo e($pbi->id); ?>/tareas/create" 
              class="pull-right btn btn-primary btn-sm">
              <i class="fa fa-plus" aria-hidden="true"></i> 
            </a> 
    

  <h3>Tareas de <b> <?php echo e($pbi->titulo); ?> </b></h3>
  <div class="row">
    
      <div class="col-sm-4">
          <h3 align="center"> <b>  PENDIENTES </b></h3>
                  
            <?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group">
                <a href="/tareas/edit/<?php echo e($pendiente->id); ?>" class="list-group-item list-group-item-action 
                    flex-column align-items-start ">
                  <div align="center" class="d-flex w-100 justify-content-between">
                    
                    <small><?php echo e($pendiente->name); ?></small>
                  </div>
                  <p class="mb-1"> <?php echo e($pendiente->descripcion); ?> </p>
                  <small> Asignado a <b> <?php echo e($pendiente->responsable); ?></small>
                </a>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="col-sm-4">
          <h3 align="center"> <b> EN CURSO </b></h3>
                  
            <?php $__currentLoopData = $en_cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $en_curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <div class="list-group">
                      <a href="/tareas/edit/<?php echo e($en_curso->id); ?>" class="list-group-item list-group-item-action 
                          flex-column align-items-start ">
                        <div align="center" class="d-flex w-100 justify-content-between">
                          
                          <small><?php echo e($en_curso->name); ?></small>
                        </div>
                        <p class="mb-1"> <?php echo e($en_curso->descripcion); ?> </p>
                        <small> Asignado a <b> <?php echo e($en_curso->responsable); ?></small>
                      </a>
              </div> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="col-sm-4">
          <h3 align="center"><b>  CONCLUIDOS </b></h3>
                  
            <?php $__currentLoopData = $concluidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concluido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <div class="list-group">
                      <a href="/tareas/edit/<?php echo e($concluido->id); ?>" class="list-group-item list-group-item-action 
                          flex-column align-items-start ">
                        <div align="center" class="d-flex w-100 justify-content-between">
                          
                          <small><?php echo e($concluido->name); ?></small>
                        </div>
                        <p class="mb-1"> <?php echo e($concluido->descripcion); ?> </p>
                        <small> Asignado a <b> <?php echo e($concluido->responsable); ?></small>
                      </a>
              </div> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div> <!-- end container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>