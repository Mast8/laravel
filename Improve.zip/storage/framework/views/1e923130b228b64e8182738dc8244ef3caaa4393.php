<?php $__env->startSection('content'); ?>
<div class="row tm-content-row">
    <h1 align=center> Proyectos </h1> 
    
    <?php if(count($projects) < 1 ): ?>
        <h2 align=center> No tiene proyectos, comience creando uno </h2>
    <?php endif; ?>
    <div class="col-md-4">
        <div class="panel panel-default ">
            <div class="panel-heading" >  <h5>Mis Proyectos</h5>
                <a  class="btn btn-primary btn-sm"  
                    href="/projects/create">
                    Crear </a> 
            </div>
            <div class="panel-body" >
                <ul class="list-group">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"> 
                        <a href="/projects/<?php echo e($project->id); ?>" > <?php echo e($project->name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    

    <?php if(count($proyectosInv)>0): ?>
    <div class="col-md-4">
        <div class="panel panel-info ">
            <div class="panel-heading">  
                <p class="text-white">Invitado a </p> 
            </div>

            <div class="panel-body" >
                <ul class="list-group">
                    <?php $__currentLoopData = $proyectosInv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyectoInv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"> 
                            <a href="/projects/<?php echo e($proyectoInv->id); ?>"><?php echo e($proyectoInv->name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>