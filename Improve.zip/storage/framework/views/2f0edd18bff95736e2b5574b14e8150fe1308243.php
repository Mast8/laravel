Estimado <?php echo e($usuario); ?>,
se le comunica que se le asigno la tarea: <?php echo e($tarea); ?>

