<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Improve')); ?></title>


   
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>




    <link rel="stylesheet" href="<?php echo e(asset ('font-awesome-5/css/fontawesome-all.min.css')); ?>">
    <!-- https://fontawesome.com/ -->



    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="<?php echo e(asset ('css/templatemo-style.css')); ?>">
    <style>

        #celda {
        color:white;
        text-align:center;
        }
    </style>

</head>

  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Gesti</a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
            
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a  class="nav-link" href="<?php echo e(route('login')); ?>">
                    <i class="fa fa-sign-in-alt" aria-hidden="true"></i> Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">
                    <i class="fa fa-user-plus" aria-hidden="true"></i> Registro</a>
                </li>
            <?php else: ?>
                <?php if(Auth::user()->role_id == 1): ?> 
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/proyectos">
                        <i class="fa fa-briefcase" aria-hidden="true"></i> Todos los Proyectos</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                        <i class="fa fa-user" aria-hidden="true"></i> Todos los Usuarios</a>
                    </li>
                <?php endif; ?>  
                
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/home')); ?>">
                    <i class="fa fa-home" aria-hidden="true"></i>Home</a>
                </li>
            <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
                    <i class="fa fa-briefcase" aria-hidden="true"></i> Proyectos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/usuarios/<?php echo e(Auth::user()->id); ?>/editar">
                <i class="fa fa-user" aria-hidden="true"></i> Perfil</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <i class="fa fa-power-off" aria-hidden="true"></i> Logout
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" 
                    method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>        
            </li>
            <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav> 
 


<body>
    
    <div id="app">
        
      

        <div class="container" >
            <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>

    <footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
            <p class="text-center text-white mb-0 px-4 small"> 
             Copyright © PROYECTO DE GRADO <b>II-2019</b>
            </p>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldContent('jqueryScript'); ?>
</body>
</html>
