<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>

    <div id="app">
        <div class="container">

            <?php if(session('success_message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success_message')); ?>

                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <h3>Edit Testimonial</h3>

            <div class="spacer"></div>

            <form class="add-testimonial form-horizontal" method="post" action="<?php echo e(route('admin.testimonials.update', $testimonial)); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo method_field('patch'); ?>


                <div class="form-group m-b-lg">
                    <label class="control-label col-lg-2" for="name">Name <span class="asterisk">*</span></label>
                    <div class="controls col-lg-6">
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $testimonial->name)); ?>" class="form-control input-xlarge" required>
                    </div> <!-- /controls -->
                </div> <!-- /form-group -->



                <div class="form-group m-b-lg">
                    <label class="control-label col-lg-2" for="quote">Quote <span class="asterisk">*</span></label>
                    <div class="controls col-lg-6">
                        <textarea name="quote" cols="40" rows="8" id="quote" class="form-control input-xlarge" required><?php echo e(old('quote', $testimonial->quote)); ?></textarea>
                    </div>
                </div> <!-- /controls -->

                <div class="form-group m-b-lg">
                    <label class="control-label col-lg-2" for="order">Order</label>
                    <div class="controls col-lg-6">
                        <input type="text" name="order" id="order" value="<?php echo e(old('order', $testimonial->order)); ?>" class="form-control input-xlarge">
                    </div> <!-- /controls -->
                </div> <!-- /form-group -->

                <div class="form-group m-b-lg">
                    <label class="control-label col-lg-2">Visible? <span class="asterisk">*</span></label>

                    <div class="controls col-lg-6">
                        <input type="radio" name="visible" id="yes" value="1" <?php echo e($testimonial->visible == 1 ? 'checked' : null); ?>>
                        <label for="yes">Yes</label>

                        <br>

                        <input type="radio" name="visible" id="no" value="0" <?php echo e($testimonial->visible == 0 ? 'checked' : null); ?>>
                        <label for="no">No</label>

                    </div> <!-- /controls -->
                </div> <!-- /form-group -->

                <div class="form-group">
                    <div class="col-lg-2"></div>
                    <div class="controls col-lg-6">
                        <div class="form-actions">
                            <button type="submit" id="create-testimonial" class="btn btn-primary btn-lg"> Update Testimonial</button>
                        </div>

                    </div> <!-- end controls -->
                </div>

            </form>
        </div> <!-- end container -->

    </div> <!-- end app -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>