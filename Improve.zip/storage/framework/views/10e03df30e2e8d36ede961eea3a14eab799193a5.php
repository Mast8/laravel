<?php $__env->startSection('content'); ?>



     
     



  <div class="col-sm-4 col-md-4 col-lg-4 pull-right">
    <div class="well well-lg" >

          <h4>Archivos</h4>
              <ul id="images_col">
                
              </ul>
              <form method="post" action="<?php echo e(route('pbis.update')); ?>" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?>

  
              
  
          <div class="form-group" >
            <label> Adjuntar documentos (png, gif,jpeg,jpg,txt,pdf,doc) 
              <span class="glyphicon glyphicon-file" aria-hidden="true"></span></label>
                <input type="file" class="form-control" name="photos[]" multiple>
          </div>

          <div class="form-group">
            <input type="submit" class="btn btn-primary"
                          value="Editar"/>
          </div>
      </form>
    </div>
  </div>


    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>