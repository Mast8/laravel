<html>
    <title> Reporte del PB </title>
<head>

    <style>
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
    tr:nth-child(even) {
        background-color: #dddddd;
    }
    </style>
</head>

<head>
<body>
    <h2 align="center">
        PRODUCT BACKLOG
    </h2>
    <table>
        <tr>
            <th>PBI</th>
            <th>SPRINT</th>
            <th>Estimacion</th>
            <th>Prioridad</th>
        </tr>
        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($proyecto->titulo); ?></td>
                <td><?php echo e($proyecto->nombre); ?></td>
                <td><?php echo e($proyecto->estimacion); ?></td>
                <td><?php echo e($proyecto->nombrePrio); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
</head>