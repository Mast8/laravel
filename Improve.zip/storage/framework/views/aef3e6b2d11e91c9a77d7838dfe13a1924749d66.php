<html>
        
    <title> Reporte de tareas </title>
<head>

    <style>
        h2 { color: #667373; }
        h3 { color: #567086; }
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
            font-size:	10px;

        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
 
                           
                       
    </style>
</head>

<head>
<body>
        
    <h2 align="center">
        ESTADO TAREAS PLANIFICADAS
    </h2>
    <h3 align="center">
        Se observan <?php echo e(count($pendientes)); ?> tareas PENDIENTES, 
        <?php echo e(count($en_curs)); ?> </b> tareas EN CURSO y 
        <?php echo e(count($concluidos)); ?> </b> tareas CONCLUIDAS.
    </h3>
    <?php if(count($pendientes) > 0 ): ?>
        <h2 align="center">
                PENDIENTES
        </h2>
        <table>
                <tr>
                    <th>PBI</th>
                    <th>TAREA</th>
                    <th>SPRINT</th>
                    <th>CREADO POR</th>
                    <th>RESPONSABLE</th>
                    <th>ESTADO</th>
                </tr>
                <?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pend->titulo); ?></td>
                        <td><?php echo e($pend->name); ?></td>
                        <td><?php echo e($pend->nombre); ?></td>
                        <td><?php echo e($pend->creado_por); ?></td>
                        <td><?php echo e($pend->responsable); ?></td>
                        <td><?php echo e($pend->nombre_est); ?></td>
                        
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
               
        </table>
    <?php endif; ?>
    <?php if(count($en_curs )>0 ): ?>
        <h2 align="center">
                EN CURSO
        </h2>

        <table>
                <tr>
                    <th>PBI</th>
                    <th>TAREA</th>
                    <th>SPRINT</th>
                    <th>CREADO POR</th>
                    <th>RESPONSABLE</th>
                    <th>ESTADO</th>
                </tr>
                <?php $__currentLoopData = $en_curs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($curso->titulo); ?></td>
                        <td><?php echo e($curso->name); ?></td>
                        <td><?php echo e($curso->nombre); ?></td>
                        <td><?php echo e($curso->creado_por); ?></td>
                        <td><?php echo e($curso->responsable); ?></td>
                        <td><?php echo e($curso->nombre_est); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
    <?php if(count($concluidos )>0 ): ?>
        <h2 align="center">
                CONCLUIDOS
        </h2>

        <table>
                <tr>
                    <th>PBI</th>
                    <th>TAREA</th>
                    <th>SPRINT</th>
                    <th>CREADO POR</th>
                    <th>CONCLUIDO POR</th>
                    <th>RESPONSABLE</th>
                    <th>ESTADO</th>
                </tr>
                <?php $__currentLoopData = $concluidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($con->titulo); ?></td>
                        <td><?php echo e($con->name); ?></td>
                        <td><?php echo e($con->nombre); ?></td>
                        <td><?php echo e($con->creado_por); ?></td>
                        <td><?php echo e($con->concluido_por); ?></td>
                        <td><?php echo e($con->responsable); ?></td>
                        <td><?php echo e($con->nombre_est); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
    <?php if(count($pendientes )==0 && count($en_curs )==0 && count($concluidos )==0): ?>
        <h2 align="center">
            NO SE TIENEN DATOS REGISTRADOS.
        </h2>
    <?php endif; ?>
</head>