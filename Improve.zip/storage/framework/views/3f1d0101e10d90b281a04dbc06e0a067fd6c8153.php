<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">
        <h3>Historias del sprint <b>  </b></h3>

        <table width="100" class="table table-striped table-hover table-reflow">
                <thead>
                    <tr>
                        <th ><strong> HISTORIA </strong></th>
                        <th ><strong> OPCIONES </strong></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <a href="/pbis/<?php echo e($pbi->id); ?>" > <?php echo e($pbi->titulo); ?></a>  </td>
                            <td> 
                                <a  href="/pbis/edit/<?php echo e($pbi->id); ?>" 
                                    class="btn btn-primary btn-sm">
                                    <i class="fa fa-edit" aria-hidden="true"></i> 
                                </a>  
                                
                                <a  onclick="return confirm('Desea eliminar la historia?')"
                                    href="/pbis/delete/<?php echo e($pbi->id); ?>" 
                                    class="btn btn-danger btn-sm">
                                    <i class="fa fa-times" aria-hidden="true"></i> 
                                </a>   
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </table>   
    </div>

    <div class="col-md-4">
        <div class="tm-bg-primary-dark tm-block">
            <h1><?php echo e($sprint->nombre); ?></h1>
            <p class="lead"><?php echo e($sprint->descripcion); ?></p>
        
            <div>
                <a href="<?php echo e(route('sprints.edit', ['id' => $sprint->id ])); ?>">
                <i class="fa fa-edit" aria-hidden="true"></i> Editar</a>
            </div>
            
            <div>
                <a  onclick="return confirm('¿Quiere eliminar el sprint?')" 
                href="<?php echo e(route('sprints.delete', ['id' => $sprint->id])); ?>" >
                <i class="fa fa-power-off" aria-hidden="true"></i> Eliminar</a>
            </div>
            
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>