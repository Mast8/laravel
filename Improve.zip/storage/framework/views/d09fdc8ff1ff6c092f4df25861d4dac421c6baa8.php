Estimado, <?php echo e($usuario); ?>

se le asigno la tarea: <?php echo e($tarea); ?>

