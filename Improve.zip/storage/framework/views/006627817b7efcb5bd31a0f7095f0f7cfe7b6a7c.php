<?php $__env->startSection('content'); ?>

<div class="row tm-content-row">
	<div class="col-md-9 col-sm-9  col-xs-9 col-lg-9">
        
    <?php if(count($comentarios)>0): ?>
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">
                <span class="glyphicon glyphicon-comment"></span> 
                Comentarios
            </h3>
        </div>
        <div class="panel-body">
            <ul class="media-list">
                
            <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"> 
                    
                    <div class="media-body">
                        <h4 class="media-heading">
                        <small> 
                                 <b> Usuario: <?php echo e($comentario->usuario); ?> </b> -
                            <?php echo e($comentario->nombres); ?> <?php echo e($comentario->apellidos); ?>

                            - <b align="right"> <?php echo e($comentario->email); ?> </b>

                            <?php if(Auth::user()->id == $comentario->user_id || Auth::user()->role_id == 1): ?>
                                <a 
                                    onclick="return confirm('¿Desea eliminar el comentario?')"
                                    href="/comentario/<?php echo e($comentario->id); ?>/eliminar"   
                                    class="btn btn-danger btn-sm"> 
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                </a>
                            <?php endif; ?>
                       <br>
                             <b>   Enviado el </b><?php echo e($comentario->fecha); ?>

                        </small>
                        </h4>
                        <p class="text-danger"> <?php echo e($comentario->mensaje); ?>  </p>
                        
                        
                    </div>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </ul>
        </div>
    </div>  
    <?php else: ?>   
        <h3> No se tienen comentarios</h3>
    <?php endif; ?>
       
	</div>
</div>
    <div>     
        <a class="btn btn-primary" 
                href="<?php echo e(route('pbis.edit', ['id' => $pbi->id] )); ?>">Volver a la historia</a>
    </div>


<div class="col-md-9 col-sm-9 col-xs-9 col-lg-9">      
    <form method="post" action="<?php echo e(route('coment.store')); ?>">
                        <?php echo e(csrf_field()); ?>


        <input type="hidden" name="id_pbi" value="<?php echo e($pbi->id); ?>">

        <div class="form-group<?php echo e($errors->has('mensaje') ? ' has-error' : ''); ?>">
            <label for="comment-content">¿Tiene alguna observación?</label>
            <textarea placeholder="Escriba su comentario" 
                        style="resize: vertical" 
                        id="comment-content"
                        required
                        name="mensaje"
                        rows="3" spellcheck="false"
                        class="form-control autosize-target text-left">
                        </textarea>
            <?php if($errors->has('mensaje')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('mensaje')); ?></strong>
                </span>
            <?php endif; ?> 
        </div>     

        <div class="form-group">
            <input type="submit" class="btn btn-primary"
                    value="Enviar"/>
        </div>
    </form>              
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>