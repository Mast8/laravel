<?php $__env->startSection('content'); ?>



<div class="row">
    <div class="col-md-8">
      <h1>Actualizar datos del sprint  <?php echo e($sprint->nombre); ?> </h1>

      <!-- Example row of columns -->
      

                                 
      <form method="post" action="<?php echo e(route('sprints.update')); ?>">
                            <?php echo e(csrf_field()); ?>


              <input type="hidden" name="sprint_id" value="<?php echo e($sprint->id); ?>">
              
              <input type="hidden" name="_method" value="put">


              <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                  <label for="company-name">Nombre<span class="required"></span></label>
                  <input   placeholder="Enter name"  
                            id="proyecto-name"
                            required
                            name="nombre"
                            spellcheck="false"
                            class="form-control"
                            value="<?php echo e($sprint->nombre); ?>"
                              />
                  <?php if($errors->has('nombre')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                    </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group">
                <label for="company-content">Descripción</label>
                <textarea class="form-control my-editor" placeholder="Información acerca del sprint"
                rows="4" id="nombre" name="description"><?php echo e($sprint->descripcion); ?></textarea>
              </div>

              <div class="form-group">
                  <input type="submit" class="btn btn-primary"
                          value="Submit"/>
              </div>
          </form>
   
      </div>



    <div class="col-md-4">
        <div class="tm-bg-primary-dark tm-block">
            <h4>Opciones</h4>
            <ol class="list-unstyled">
              <li><a href="/projects/<?php echo e($sprint->id); ?>"><i class="fa fa-building-o" 
                aria-hidden="true"></i> Product backlog</a></li>
              <li><a href="/projects"><i class="fa fa-building" 
                aria-hidden="true"></i> Proyectos</a></li>
            </ol>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>