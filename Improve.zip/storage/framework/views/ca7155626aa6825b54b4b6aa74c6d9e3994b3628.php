<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-8">
        

            <h4>Miembros registrados  <?php echo e($num_miembros); ?> </h4>
            <?php if( $num_miembros > 0 ): ?> 

    <table width="100" class="table">
        <thead>
            <tr>
                <th ><strong> USUARIO </strong></th>
                <th ><strong> APELLIDO </strong></th>
                <th ><strong> NOMBRE </strong></th>
                <th ><strong> EMAIL </strong></th>
                <th ><strong> ELIMINAR </strong></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $miembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($miembro->usuario); ?> </a>   </td>
                    <td> <?php echo e($miembro->apellidos); ?></td>
                    <td> <?php echo e($miembro->nombres); ?> </td>
                    <td> <?php echo e($miembro->email); ?> </td>
                    <td>
                        <a 
                            onclick="return confirm('¿Quiere eliminar al usuario?')"
                            href="<?php echo e(route('miembros.eliminar', ['id' => $miembro->id])); ?>" 
                            class="btn btn-danger btn-sm">
                            <i class="fa fa-trash" aria-hidden="true"></i>
                        </a>
                    </td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
 <?php endif; ?>
</div>

    <div class="col-md-4">
        <div class="tm-bg-primary-dark tm-block ">
                <h3><?php echo e($project->name); ?></h3>
                <p class="lead"><?php echo e($project->description); ?></p>
                
                <a href="/projects/<?php echo e($project->id); ?>"><i 
                    class="fa fa-undo" aria-hidden="true"></i> Backlog</a>

            <h4>Añadir miembro</h4>
        
            <form id="add-user" action="<?php echo e(route('equipo.anadir')); ?>"  method="POST" >
                <?php echo e(csrf_field()); ?>

                <div class="input-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                
                    <input class="form-control" name = "project_id" id="project_id" 
                    value="<?php echo e($project->id); ?>" type="hidden">
                    
                    
                    <input type="text" required class="form-control" id="email"  
                    name ="email" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?> 

                    <button class="btn btn-primary" type="submit" id="addMember" >Añadir</button>
               
                </div>
            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>