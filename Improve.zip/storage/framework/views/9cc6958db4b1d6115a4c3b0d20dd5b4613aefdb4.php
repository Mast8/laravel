<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">

    <h1>Nueva tarea</h1>



    <form method="post" action="<?php echo e(route('tareas.store')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


      <input type="hidden" name="idPbi" value="<?php echo e($idhistoria); ?>">

          <div class="form-group<?php echo e($errors->has('titulo') ? ' has-error' : ''); ?>">
              <label for="company-name">Título<span class="required">*</span></label>
              <input   placeholder="Título de la tarea"  
                        id="company-name"
                        required
                        name="titulo"
                        spellcheck="false"
                        class="form-control"
                        value="<?php echo e(old('titulo')); ?>"
                          />
                <?php if($errors->has('titulo')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('titulo')); ?></strong>
                  </span>
                <?php endif; ?> 
          </div>


          <div class="form-group">
              <label for="company-content">Descripción</label>
              <textarea placeholder="Descripción de la tarea" 
                        style="resize: vertical" 
                        id="company-content"
                        name="description"
                        rows="5" spellcheck="false"
                        class="form-control autosize-target text-left"><?php echo e(old('description')); ?>

              </textarea>
          </div>

          <div class="form-group<?php echo e($errors->has('estado') ? ' has-error' : ''); ?>">
             
              <label>Estado <span class="glyphicon glyphicon-warning-sign" 
                aria-hidden="true"></span></label>

              <select name="estado" class="form-control"  
                data-style="btn-info" style="width:20%;">
                <option value="">Elija un estado</option>
                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($estado->id); ?>" <?php echo e(old('estado') ? 
                  'selected' : ''); ?>><?php echo e($estado->nombre_est); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if($errors->has('estado')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('estado')); ?></strong>
                </span>
              <?php endif; ?> 

          </div>

          <div class="form-group<?php echo e($errors->has('asignar') ? ' has-error' : ''); ?>">
            <label>Asignar: <span class="glyphicon glyphicon-warning-sign" 
              aria-hidden="true"></span></label>

            <select name="asignar" class="form-control" 
              data-style="btn-info" style="width:40%;">
              <option value="">Elija un miembro</option>
              <?php $__currentLoopData = $miembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($miembro->user_id); ?>" <?php echo e(old('asignar') ? 
                'selected' : ''); ?>><?php echo e($miembro->email); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

              <?php if($errors->has('asignar')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('asignar')); ?></strong>
                </span>
              <?php endif; ?> 
          </div>
        
          <div class="form-group">
              <input type="submit" class="btn btn-primary"
                      value="Crear"/>
          </div>
      </form>
   

    </div>
</div>




    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>