
 <div class="row">
		<div class="col-md-9 col-sm-9  col-xs-9 col-lg-9">
        
            <!-- Fluid width widget -->        
    	    <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-comment"></span> 
                        Comentarios
                    </h3>
                </div>
                <div class="panel-body">
                    <ul class="media-list">
                        
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="media">
                            
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <small> 
                                    
                                    <a href="users/<?php echo e($comment->user->id); ?> " > 
                                        <?php echo e($comment->user->first_name); ?> <?php echo e($comment->user->last_name); ?>

                               -  <?php echo e($comment->user->email); ?> </a> 
                               <br>
                                        Enviado el <?php echo e($comment->created_at); ?>

                                    </small>
                                </h4>
                                <p> <?php echo e($comment->body); ?>  </p>
                                
                            </div>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <!-- End fluid width widget --> 
            
		</div>
	</div>
