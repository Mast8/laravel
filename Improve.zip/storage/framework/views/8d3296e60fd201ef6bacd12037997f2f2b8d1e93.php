<?php $__env->startSection('content'); ?>



    
            <a class="btn btn-primary" 
              href="<?php echo e(route('pbis.edit', ['id' => $pbi->id] )); ?>">
              Volver a la historia</a>
            
            <?php if(count($miembros) < 1): ?>
              <h3 align="center"> Debe invitar Miembros para registrar tareas. </h3>
              
            <?php else: ?>
              <a  
                href="<?php echo e($pbi->id); ?>/tareas/create" 
                class="pull-right btn btn-primary btn-sm">
                <i class="fa fa-plus" aria-hidden="true"></i> 
              </a> 
            <?php endif; ?>
            <div class="text-center">
              <a class="btn btn-primary" href="/proyecto/<?php echo e($proyecto); ?>/miembros"> 
                Registrar miembros</a>
            </div>
    
  <h3>Tareas de <b> <?php echo e($pbi->titulo); ?> </b></h3>
  <div class="row">
    
      <div class="col-sm-4">
      <h3 align="center"> <b> <?php echo e($num_pendientes); ?> PENDIENTES </b></h3>
                  
            <?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group">
                <a href="/tareas/edit/<?php echo e($pendiente->id); ?>" class="list-group-item list-group-item-action 
                    flex-column align-items-start ">
                  <div align="center" class="d-flex w-100 justify-content-between">
                    
                    <small><?php echo e($pendiente->name); ?></small>
                  </div>
                  <p class="mb-1"> <?php echo e($pendiente->descripcion); ?> </p>
                  <small> Asignado a: <b> <?php echo e($pendiente->responsable); ?></b>
                    <p class="mb-1">Creado por: <b> <?php echo e($pendiente->creado_por); ?> </b> </p>
                </a>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="col-sm-4">
          <h3 align="center"> <b> <?php echo e($num_en_cursos); ?> EN CURSO </b></h3>
                  
            <?php $__currentLoopData = $en_cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $en_curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <div class="list-group">
                      <a href="/tareas/edit/<?php echo e($en_curso->id); ?>" 
                        class="list-group-item list-group-item-action 
                          flex-column align-items-start ">
                        <div align="center" class="d-flex w-100 justify-content-between">
                          
                          <small><?php echo e($en_curso->name); ?></small>
                        </div>
                        <p class="mb-1"> <?php echo e($en_curso->descripcion); ?> </p>
                        <small> Asignado a <b> <?php echo e($en_curso->responsable); ?> </b>
                        <p class="mb-1">Creado por: <b> <?php echo e($en_curso->creado_por); ?> </b> </p>
                         
                      </a>
              </div> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="col-sm-4">
          <h3 align="center"><b> <?php echo e($num_concluidos); ?> CONCLUIDOS </b></h3>
                  
            <?php $__currentLoopData = $concluidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concluido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <div class="list-group">
                      <a href="/tareas/edit/<?php echo e($concluido->id); ?>" 
                        class="list-group-item list-group-item-action 
                          flex-column align-items-start ">
                        <div align="center" class="d-flex w-100 justify-content-between">
                          
                          <small><?php echo e($concluido->name); ?></small>
                        </div>
                        <p class="mb-1"> <?php echo e($concluido->descripcion); ?> </p>
                        <small> Asignado a <b> <?php echo e($concluido->responsable); ?>  </b>
                        
                        <p class="mb-1">Creado por: <b> <?php echo e($concluido->creado_por); ?> </b> </p>
                        <p class="mb-1">Concluido por: <b> <?php echo e($concluido->concluido_por); ?> </b> </p>
                        

                      </a>
              </div> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div> <!-- end container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>