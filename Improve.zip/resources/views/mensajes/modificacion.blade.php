Estimado {{ $usuario }},
se le informa que se modifico la siguiente tarea: {{ $tarea }}
