<?php $__env->startSection('content'); ?>




  <h1>Crear nuevo proyecto </h1>

  <div class="row">
      <div class="col-md-8">
       <!-- <div class="row justify-content-md-center">-->
      <form method="post" action="<?php echo e(route('projects.store')); ?>">
                            <?php echo e(csrf_field()); ?>



              <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                  <label for="project-name">Nombre<span class="required">*</span></label>
                  <input   placeholder="Nombre del proyecto"  
                            id="project-name"
                            required
                            name="nombre"
                            spellcheck="false"
                            class="form-control"
                            value="<?php echo e(old('nombre')); ?>"
                              />
                  <?php if($errors->has('nombre')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                    </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group">
                  <label for="project-content">Descripción</label>
                  <textarea placeholder="Descripción del proyecto" 
                            style="resize: vertical" 
                            id="project-content"
                            name="description"
                            rows="5" spellcheck="false"
                            class="form-control autosize-target text-left"><?php echo e(old('description')); ?>                
                            </textarea>
              </div>
              <div class="form-group">
                  <input type="submit" class="btn btn-primary"
                          value="Crear"/>
              </div>
          </form>
      </div>



      <div class="col-md-4">
          <div class="tm-bg-primary-dark tm-block">
            <h4>Opciones</h4>
            <ol class="list-unstyled">
              <li><a href="/projects"><i class="fa fa-briefcase" 
                aria-hidden="true"></i> Mis proyectos</a></li>
            </ol>
          </div>
      </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>