<?php $__env->startSection('content'); ?>

     
<div class="col-md-8">
    <h1>Crear Sprint </h1>
      <form method="post" action="<?php echo e(route('sprints.create')); ?>">
                            <?php echo e(csrf_field()); ?>


          <input   
          class="form-control"
          type="hidden"
                  name="idproject"
                  dd($id_proyec);
                  value="<?php echo e($id_proyec); ?>"
                    />
          

          <div class="form-group">
              <label for="company-name">Nombre<span class="required">*</span></label>
              <input    placeholder="Nombre del sprint"  
                        id="company-name"
                        required
                        name="name"
                        spellcheck="false"
                        class="form-control"
                          />
          </div>


          <div class="form-group">
              <label for="company-content">Descripción</label>
              <textarea class="form-control" placeholder="Descripcion del sprint"
              rows="4" id="nombre" name="description"></textarea>
          </div>

        
          <div class="form-group">
              <input type="submit" class="btn btn-primary"
                      value="Crear"/>
          </div>
          
      </form>
  </div>
<?php $__env->stopSection(); ?>
   

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/moment.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
    
    <script>
              $('#datepicker0').datetimepicker( {
                    //format: 'YYYY-MM-DD',  // YEAR-MONTH-DAY hour:minute:seconds
                });
                /*$('#datetimepicker1').datetimepicker( {
                    defaultDate:'now',  // defaults to today
                    format: 'YYYY-MM-DD hh:mm:ss',  // YEAR-MONTH-DAY hour:minute:seconds
                    minDate:new Date()  // Disable previous dates, minimum is todays date
                });*/
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>