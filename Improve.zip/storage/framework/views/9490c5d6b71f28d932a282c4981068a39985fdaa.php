<?php $__env->startSection('content'); ?>



     
<div class="row">
    <div class="col-md-8">
        <h1>Actualizar datos de la tarea: 
          <div> <?php echo e($tarea->name); ?> 
              <a 
                onclick="return confirm('¿Desea eliminar la tarea?')"
                href="/tareas/<?php echo e($tarea->id); ?>/eliminar"   
                class="btn btn-danger btn-sm"> 
                <i class="fa fa-times" aria-hidden="true"></i>
              </a>
          </div>
          
        </h1>
  
                                   
        <form method="post" action="<?php echo e(route('tareas.update')); ?>" >
                              <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id_tarea" value="<?php echo e($tarea->id); ?>">
  
  
              
              <div class="form-group">
                <label>Título</label>
                     <input type="text" class="form-control" placeholder="Título de la tarea"
                      name="titulo" value="<?php echo e($tarea->name); ?>">
              </div>

              <div class="form-group<?php echo e($errors->has('descripcion') ? ' has-error' : ''); ?>">
                <label for="company-content">Descripción</label>
                <textarea class="form-control my-editor" placeholder="Información de la tarea"
                    rows="4" id="nombre" name="descripcion"><?php echo e($tarea->descripcion); ?></textarea>

                     <?php if($errors->has('descripcion')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('descripcion')); ?></strong>
                        </span>
                    <?php endif; ?> 
              </div>

              <div class="form-group">
                  <label>Asignado a: </label>
                  <?php if($asignado_a!=null): ?>
                  <?php echo e($asignado_a->usuario); ?>

                  <?php else: ?> Nadie
                  <?php endif; ?>
              </div>

              <div class="form-group">
                <label>Asignar a  <span class="glyphicon glyphicon-warning-sign" 
                  aria-hidden="true"></span></label>
                <select name="asignar" class="form-control" data-style="btn-info" style="width:15%;">
                  
                  <?php $__currentLoopData = $miembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($miembro->id); ?>"><?php echo e($miembro->usuario); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </select>
              </div>

              <div class="form-group">
                  <label>Estado actual: </label>
                  <?php echo e($estado_act->nombre_est); ?>

              </div>

              <div class="form-group">
                  <label>Estado  <span class="glyphicon glyphicon-warning-sign" 
                    aria-hidden="true"></span></label>
                  <select name="estado" class="form-control" data-style="btn-info" style="width:15%;">
                    
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nombre_est); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </select>
              </div>
    
              <div class="form-group">
                <input type="submit" class="btn btn-primary"
                              value="Editar"/>
              </div>
         </form>
        </div>
 
 

        <div class="col-md-4">
            <div class="tm-bg-primary-dark tm-block ">
        
            
       <?php if( count($images_set) > 0 ): ?> 
            <h4>Archivos</h4>
            <table width="100"  class="table table-striped table-hover table-reflow">
              <thead>
                  <tr>
                      <th ><strong> Descargar </strong></th>
                      <th ><strong> Eliminar </strong></th>
                  </tr>
              </thead>

              <tbody>
                  <?php $__currentLoopData = $images_set; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>  
                            <a 
                              href="<?php echo asset("images/$archivo") ?>" 
                              data-lightbox="images-set"> <?php echo e($archivo); ?>

                            </a>
                          </td>

                          <td>  
                            <a  
                              onclick="return confirm('¿Quiere eliminar el documento?')"
                              class="btn btn-danger btn-sm" 
                              href="<?php echo e(route('tarea.deletefile', [ 'id' => $archivo])); ?>">
                              <i class="fa fa-trash" aria-hidden="true"></i>
                            </a>
                          </td>    
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>

          </table>
        <?php endif; ?>

          <form method="post" action="<?php echo e(route('tareas.subir')); ?>" 
              enctype="multipart/form-data">  <?php echo e(csrf_field()); ?>  
              <input type="hidden" name="id_tarea" value="<?php echo e($tarea->id); ?>">

              <div class="form-group<?php echo e($errors->has('photos') ? ' has-error' : ''); ?>">
                  <label> Adjuntar documentos (png, gif,jpeg,jpg,txt,pdf,doc) 
                  <i class="fa fa-file" aria-hidden="true"></i></label>
                      <input type="file" class="form-control" name="photos[]" multiple>
                    <?php if($errors->has('photos')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('photos')); ?></strong>
                      </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group">
                <input type="submit" class="btn btn-primary"  value="Subir"/>
              </div>

          </form>
    </div>
  </div>
</div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>