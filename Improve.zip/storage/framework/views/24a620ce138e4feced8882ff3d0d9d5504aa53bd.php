<html>
        
    <title> Reporte del estado de tareas </title>
<head>

    <style>
        h2 { color: #667373; }
        h3 { color: #567086; }
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
            font-size:	10px;

        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
    
    footer { position: fixed; right: 0px; bottom: 10px; text-align: center; 
        border-top: 1px solid black;}
        #footer .page:after { content: counter(page, decimal); }
        @page  { margin: 20px 30px 40px 50px; }
    </style>
</head>

<head>
<body>
    
    <h2 align="center">
        TAREAS PLANIFICADAS
    </h2>
    <?php if(count($pbis)>0): ?>
    <h3 align="center">
        Se registraron <?php echo e(count($pbis)); ?> tareas.
    </h3>
        <table>
            <tr>
                <th>PBI</th>
                <th>TAREA</th>
                <th>SPRINT</th>
                <th>CREADA POR</th>
                <th>RESPONSABLE</th>
                <th>ESTADO</th>
            </tr>
            <?php $__currentLoopData = $pbis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            
                <tr>
                    <td><?php echo e($pbi->titulo); ?></td>
                    <td><?php echo e($pbi->name); ?></td>
                    <td><?php echo e($pbi->nombre); ?></td>
                    <td><?php echo e($pbi->creado_por); ?></td>
                    <td><?php echo e($pbi->email); ?></td>
                    <td><?php echo e($pbi->nombre_est); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
    <?php else: ?>
        <h2 align="center">
            NO SE TIENEN DATOS REGISTRADOS.
        </h2>
    <?php endif; ?>
</head>