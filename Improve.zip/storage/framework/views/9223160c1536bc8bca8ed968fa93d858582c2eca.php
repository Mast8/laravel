<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        

            <h4 align=center> Tareas en papelera  <?php echo e($num_eliminados); ?> </h4>
            <?php if( $num_eliminados > 0 ): ?> 

    <table width="100" class="table table-striped table-hover table-reflow">
        <thead>
            <tr>
                <th ><strong> Título historia </strong></th>
                <th ><strong> Sprint </strong></th>
                <th ><strong> Tarea </strong></th>
                <th ><strong> Tarea creada por </strong></th>
                
                <th ><strong> Asignada a </strong></th>
                <th ><strong> Historial </strong></th>
                <th ><strong> Eliminar definitivamente </strong></th>
                <th ><strong> Recuperar tarea </strong></th>
            </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <a href="/pbis/edit/<?php echo e($tarea->pbi_id); ?>" > <?php echo e($tarea->titulo); ?></a> </td>
                <td> <a href="/sprints/<?php echo e($tarea->sprint_id); ?>" > <?php echo e($tarea->nombre); ?></a></td>
                <td>  <a href="/tareas/edit/<?php echo e($tarea->id); ?>" > <?php echo e($tarea->name); ?></a> </td>
                <td>  <?php echo e($tarea->creado_por); ?> </td>
                <td>  <?php echo e($tarea->responsable); ?> </td>
                
                <td>  
                    <a href="/tareas/<?php echo e($tarea->id); ?>/historial" class="btn btn-primary btn-sm">
                        <i class="fa fa-book" aria-hidden="true"></i> 
                        Historial</a>
                </td>
                <td> 
                    <a 
                        onclick="return confirm('¿Quiere eliminar la tareas y todos sus registros?')"
                        href="/tareas/<?php echo e($tarea->id); ?>/eliminar"  
                        class="btn btn-danger btn-sm"> 
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </a>
                </td>
                <td> 
                    <a 
                        href="/tareas/recuperar/<?php echo e($tarea->id); ?>"   
                        class="btn btn-primary btn-sm"> 
                        <i class="fa fa-check" aria-hidden="true"></i>
                    </a>
                </td>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
    </table>
 <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>