<html>
    
    <title> Reporte Usuarios </title>
<head>

    <style>
        h1 { color: #8f9595; }
        h2 { color: #667373; }
        table{
            font-family:arial, sans-serif;
            border-collapse:collapse;
            width: 100%;
            font-size:	10px;
        }
    td, th {
        border: 1px solid #dddddd;
        text-align:left;
        padding: 8px;
    }
    tr:nth-child(even) {
        background-color: #dddddd;
    }
    </style>
</head>

<head>
<body>

    PROYECTO: <h1 >  <?php echo e($project->name); ?> </h1>
    <h2 align="center">
        PROPIETARIO
    </h2>
    
    <table>
        <tr>
            <th>NOMBRE</th>
            <th>USUARIO</th>
            <th>EMAIL</th>
        </tr>
       
        <tr>
            <td><?php echo e($dueno->apellidos. " ".$dueno->nombres); ?></td>
            <td><?php echo e($dueno->usuario); ?></td>
            <td><?php echo e($dueno->email); ?></td>
        </tr>
    </table>

    <h2 align="center">
        MIEMBROS
    </h2>
    <?php if(count($miembros)>0): ?>
        <table>
            <tr>
                <th>NOMBRE</th>
                <th>USUARIO</th>
                <th>EMAIL</th>
                   
            </tr>

            <?php $__currentLoopData = $miembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($miembro->apellidos. " ".$miembro->nombres); ?></td>
                    <td><?php echo e($miembro->usuario); ?></td>
                    <td><?php echo e($miembro->email); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    <?php else: ?>
    <h2 align="center">
        NO SE TIENEN USUARIOS REGISTRADOS, INVITELOS!
    </h2>
    <?php endif; ?>
    
</head>