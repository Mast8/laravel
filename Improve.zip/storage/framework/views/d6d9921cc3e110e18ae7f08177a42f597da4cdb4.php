<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        

            <h4 align=center> <?php echo e($num_acciones); ?> Cambios registrados en la historia   </h4>
            <?php if( $num_acciones > 0 ): ?> 

    <table width="100" class="table table-striped table-hover table-reflow">
        <thead>
            <tr>
                <th ><strong> Título </strong></th>
                <th ><strong> Creado por </strong></th>
                <th ><strong> Acción </strong></th>
                <th ><strong> Motivo </strong></th>
                <th ><strong>  Acción Realizada por </strong></th>
                <th ><strong> Realizada el </strong></th>
            </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $acciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <a href="/pbis/edit/<?php echo e($accion->id); ?>" > <?php echo e($accion->titulo); ?></a> </td>
                <td> <?php echo e($accion->creado_por); ?> </td>
                <td>  <?php echo e($accion->accion); ?> </td>
                <td>  <?php echo e($accion->motivo); ?> </td>
                <td>  <?php echo e($accion->realizada_por); ?> </td>
                <td>  <?php echo e($accion->creada_el); ?> </td>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
    </table>
 <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>