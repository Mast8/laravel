<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-8">
      
     
    <h1>Nueva historia de usuario  </h1>



      <form method="post" action="<?php echo e(route('pbis.store')); ?>">
                            <?php echo e(csrf_field()); ?>


       <input type="hidden" name="idProyecto" value="<?php echo e($idProy); ?>"> 

              <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                  <label for="company-name">Título<span class="required"></span></label>
                  <input   placeholder="Titulo de la historia"  
                            id="company-name"
                            required
                            name="nombre"
                            spellcheck="false"
                            class="form-control"
                              />
                  <?php if($errors->has('nombre')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                    </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="company-name">Descripción </label>
                    <textarea placeholder="Descripcion de la historia" 
                            style="resize: vertical" 
                            id="company-content"
                            name="description"
                            rows="5" spellcheck="false"
                            class="form-control autosize-target text-left">
                            </textarea>
                  <?php if($errors->has('description')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group<?php echo e($errors->has('prioridad') ? ' has-error' : ''); ?>">
                  <label> Prioridad </label>
                  <select name="prioridad" class="form-control" 
                  data-style="btn-info" style="width:35%;">
                  <option value="">Seleccion prioridad</option>
                    <?php $__currentLoopData = $prioris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($priori->id); ?>"><?php echo e($priori->nombrePrio); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
     
                  <?php if($errors->has('prioridad')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('prioridad')); ?></strong>
                  </span>
                <?php endif; ?> 
              </div>

              <div class="form-group<?php echo e($errors->has('sprint') ? ' has-error' : ''); ?>">
                  <label> Sprint </label>
                  <select name="sprint" class="form-control" 
                  data-style="btn-info" style="width:35%;">
                  
                  <option value="">Elija Sprint</option>
                    <?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($sprint->id); ?>"><?php echo e($sprint->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('sprint')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('sprint')); ?></strong>
                  </span>
                  <?php endif; ?> 
              </div>

              <div class="form-group<?php echo e($errors->has('estimacion') ? ' has-error' : ''); ?>">
                <label for="company-name">Estimación de esfuerzo 
                <input   placeholder="Esfuerzo estimado"  
                          id="company-name"
              
                          type="number"
                          name="estimacion"
                          spellcheck="false"
                          class="form-control"
                         
                            /> </label>
                <?php if($errors->has('estimacion')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('estimacion')); ?></strong>
                  </span>
                <?php endif; ?> 
            </div>

              <div class="form-group">
                  <input type="submit" class="btn btn-primary"
                          value="Crear"/>
              </div>
          </form>


      </div>
</div>





    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>