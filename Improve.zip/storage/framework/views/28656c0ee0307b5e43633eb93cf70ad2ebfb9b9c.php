<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>

    <div id="app">
        <div class="container">
            <div class="row">
                    <a href="<?php echo e(route('tareas.create', ['idpbi' => $pbi->id])); ?>" 
                            class="pull-right btn btn-primary btn-sm">
                            <span 
                            class="glyphicon glyphicon-plus" aria-hidden="true"></span> 
                    </a> 
                <h3>Tareas de <b> <?php echo e($pbi->titulo); ?> </b></h3>

                 <visibility-draggable :testimonials-visible="<?php echo e($testimonialsVisible); ?>" 
                 :testimonials-not-visible="<?php echo e($testimonialsNotVisible); ?>"
                 :done="<?php echo e($done); ?>" >
                </visibility-draggable>
                
            </div>
            
        </div> <!-- end container -->

    </div> <!-- end app -->

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>