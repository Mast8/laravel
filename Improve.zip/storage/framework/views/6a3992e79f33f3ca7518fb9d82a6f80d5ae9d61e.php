<?php $__env->startSection('content'); ?>


<div class="row tm-content-row">
    <div class="col-md-12">
        <h1 align=center>
            <?php echo e($num_proyects); ?> Proyecto(s) registrado(s) 
        </h1>
        <?php if($num_proyects>0): ?>
        <table width="100" class="table table-striped table-hover table-reflow">
            <thead>
                <tr>
                    <th ><strong> ID </strong></th>
                    <th ><strong> Proyecto </strong></th>
                    <th ><strong> Descripción </strong></th>
                    <th ><strong> Eliminar </strong></th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($proyecto->id); ?></td>
                        <td>
                            <a href="/projects/<?php echo e($proyecto->id); ?>" > <?php echo e($proyecto->name); ?></a>
                        </td>
                        <td> <?php echo e($proyecto->description); ?></td>
                        <td>
                            <a  
                                onclick="return confirm('Esta accion eliminara todo el proyecto')"
                                href="/admin/<?php echo e($proyecto->id); ?>/eliminar" 
                                class="btn btn-danger btn-sm">
                                <i class="fa fa-times" aria-hidden="true"></i> 
                            </a> 
                        </td>
                        
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>

        
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>