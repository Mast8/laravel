<?php $__env->startSection('title', 'Landing Page'); ?>

<?php $__env->startSection('content'); ?>

    <div id="app">
        <div class="container">

            <h1>Testimonials</h1>
            <div class="testimonials-slider">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-slide">
                        <div class="testimonial-name"><?php echo e($testimonial->name); ?></div>
                        <div class="testimonial-quote"><?php echo e($testimonial->quote); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div> <!-- end testimonials-slider -->
        </div>

    </div> <!-- end app -->

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>